package com.example.mealplan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import android.widget.ListView
import android.widget.Button
import android.widget.EditText
import android.content.Context
import android.content.SharedPreferences.Editor
import androidx.core.content.edit

public class MealPlan1 : AppCompatActivity() {

    private lateinit var mealList: ListView
    private lateinit var mealInput: EditText
    //array that holds stuff








    private var meals = ArrayList<String>()  // Hold the meals of the meal plans
    private lateinit var mealAdapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_plan1)


        var receivedArray = intent.getStringArrayExtra("myArray") ?: emptyArray()
       var names1 = arrayOf("")
        names1 = receivedArray.copyOf()
// calling the id of the listview and the text input
        mealList = findViewById(R.id.listview)
        mealInput = findViewById(R.id.Holder)


//getSharedPreference to save the contents of the list
        val preferences = getSharedPreferences("MealPreferences", Context.MODE_PRIVATE)
        val mealSet = preferences.getStringSet("Meals", null)


        // transfer contents of the array names to meals


        meals = arrayListOf(*names1)

        //the code responsible for adding the meal
        mealSet?.let { //add the contents of meals
            meals.addAll(it)
        }

        mealAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, meals)
        mealList.adapter = mealAdapter

        val addMealButton = findViewById<Button>(R.id.addButton)
        addMealButton.setOnClickListener {
            val meal = mealInput.text.toString()
            if (meal.isNotEmpty()) {
                meals.add(meal)
                mealAdapter.notifyDataSetChanged()
                mealInput.text.clear()
                preferences.edit {
                    putStringSet("Meals", meals.toSet())
                }
            }
        }

        mealList.setOnItemLongClickListener { _, _, position, _ ->
            meals.removeAt(position)
            mealAdapter.notifyDataSetChanged()
            preferences.edit {
                putStringSet("Meals", meals.toSet())
            }
            true
        }
    }
}